#!/usr/bin/env bash

python3 todo.py "$@"
