import sys
import os.path
from datetime import datetime

pwd = os.getcwd()
todoFile = os.path.join(pwd,"todo.txt")
doneListFile = os.path.join(pwd,"done.txt")

def Help():
    todohelp = \
        """Usage :-
$ ./todo add "todo item"  # Add a new todo
$ ./todo ls               # Show remaining todos
$ ./todo del NUMBER       # Delete a todo
$ ./todo done NUMBER      # Complete a todo
$ ./todo help             # Show usage
$ ./todo report           # Statistics"""
    sys.stdout.buffer.write(todohelp.encode('utf8'))


def Add(st):
    todoFile = os.path.join(pwd,"todo.txt")    
    if os.path.isfile(todoFile) :
        with open(todoFile, 'r') as reader:
            data = reader.read()
        with open(todoFile, 'w') as writer:
            writer.write(data + st + '\n')
    else:
        with open(todoFile, 'w') as todoFile:
            todoFile.write(st + '\n')
    sys.stdout.buffer.write('Added todo: "{}"'.format(st).encode('utf8'))


def List():    
    if os.path.isfile(todoFile) :
        with open(todoFile, 'r') as reader:
            data = reader.readlines()
        ct = len(data)
        st = ''
        
        for line in reversed(data) :
            if(line.endswith("\n")):
                line = line.rstrip('\n') + "\n"
            st += '[{}] {}'.format(ct, line, end = '')
            ct -= 1
        sys.stdout.buffer.write(st.encode('utf8'))
    else:
        sys.stdout.buffer.write('There are no pending todos!'.encode('utf8'))


def Delete(num):
    if os.path.isfile(todoFile):
        with open(todoFile, 'r') as reader:
            data = reader.readlines()
        ct = len(data)
        if num > ct or num <= 0:
            sys.stdout.buffer.write('Error: todo #{} does not exist. Nothing deleted.'.format(num).encode('utf8'))
        else:
            with open(todoFile, 'w') as writer:
                count = 1
                for line in data:                    
                    if count != num:
                        writer.write(line)
                    count = count + 1
                    ct -= 1
            sys.stdout.buffer.write('Deleted todo #{}'.format(num).encode('utf8'))
    else:

        sys.stdout.buffer.write('Error: todo #{} does not exist. Nothing deleted.'.format(num).encode('utf8'))


def Done(num):
    if os.path.isfile(todoFile):
        with open(todoFile, 'r') as reader:
            data = reader.readlines()
        ct = len(data)
        if num > ct or num <= 0:
            sys.stdout.buffer.write('Error: todo #{} does not exist.'.format(num).encode('utf8'))
        else:
            with open(todoFile, 'w') as writer:
                count = 1
                if os.path.isfile(doneListFile):
                    with open(doneListFile, 'r') as doneFileOri:
                        doneData = doneFileOri.read()
                    with open(doneListFile, 'w') as doneFileMod:
                        for line in data:
                            if count == num:
                                doneFileMod.write('x '+ datetime.today().strftime('%Y-%m-%d') + ' ' + line)
                            else:
                                writer.write(line)
                            count = count + 1
                            ct -= 1
                        doneFileMod.write(doneData)
                else:
                    with open(doneListFile, 'w') as doneFileMod:
                        for line in data:
                            if count == num:
                                doneFileMod.write('x '+ datetime.today().strftime('%Y-%m-%d') + ' ' + line)
                            else:
                                writer.write(line)
                            count = count + 1
                            ct -= 1
            sys.stdout.buffer.write('Marked todo #{} as done.'.format(num).encode('utf8'))
    else:
        sys.stdout.buffer.write('Error: todo #{} does not exist.'.format(num).encode('utf8'))


def Report():
    countTodo = 0
    countDone = 0
    todoFile = os.path.join(pwd,"todo.txt")
    if os.path.isfile(todoFile):
        with open(todoFile, 'r') as todoFile:
            todoData = todoFile.readlines()
        countTodo = len(todoData)
    if os.path.isfile(doneListFile):
        countDone = 0
        with open(doneListFile, 'r') as doneFile:
            doneData = doneFile.readlines()
            for i in doneData:
                temp = i.split()
                if temp[1] == str(datetime.today().strftime('%Y-%m-%d')):
                    countDone += 1
    st = datetime.today().strftime('%Y-%m-%d') \
        + ' Pending : {} Completed : {}'.format(countTodo, countDone)
    sys.stdout.buffer.write(st.encode('utf8'))


def main():
    if len(sys.argv) == 1:
        Help()
    elif sys.argv[1] == 'help':
        if len(sys.argv) == 2:
            Help()
        else:
            sys.stdout.buffer.write('Too Many Arguments for help! Please use "./todo help" for Usage Information'.encode('utf8'))
    elif sys.argv[1] == 'ls':
        if len(sys.argv) == 2:
            List()
        else:
            sys.stdout.buffer.write('Too Many Arguments for ls! Please use "./todo help" for Usage Information'.encode('utf8'))
    elif sys.argv[1] == 'add':
        if len(sys.argv) == 3:
            Add(sys.argv[2])
        else:
            sys.stdout.buffer.write('Error: Missing todo string. Nothing added!'.encode('utf8'))
    elif sys.argv[1] == 'del':
        if len(sys.argv) == 3:
            try:
                val = int(sys.argv[2])
                Delete(int(sys.argv[2]))
            except ValueError:
                sys.stdout.buffer.write('Given arguement for del is not an integer! Please use "./todo help" for Usage Information'.encode('utf8'
                        ))
        else:
            sys.stdout.buffer.write('Error: Missing NUMBER for deleting todo.'.encode('utf8'))
    elif sys.argv[1] == 'done':
        if len(sys.argv) == 3:
            try:
                val = int(sys.argv[2])
                Done(int(sys.argv[2]))
            except ValueError:
                sys.stdout.buffer.write('Given arguement for done is not an integer! Please use "./todo help" for Usage Information'.encode('utf8'
                        ))
        else:
            sys.stdout.buffer.write('Error: Missing NUMBER for marking todo as done.'.encode('utf8'))
    elif sys.argv[1] == 'report':
        if len(sys.argv) == 2:
            Report()
        else:
            sys.stdout.buffer.write('Too Many Arguments for report! Please use "./todo help" for Usage Information'.encode('utf8'))
    else:
        sys.stdout.buffer.write('Option Not Available. Please use "./todo help" for Usage Information'.encode('utf8'))


if __name__ == '__main__':
    main()